import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { IAnimalitos } from '../interfaces/ianimalitos'; 
import { environment } from 'src/environments/environment';
import { IAnimalito } from '../interfaces/ianimalito';


@Injectable({
  providedIn: 'root'
})
export class AnimalitosService {

  constructor(private http: HttpClient) { }


  listarAnimalitos():Observable<IAnimalitos>{
    return this.http.get<IAnimalitos>(`${environment.apiURL}/animalitos`)
  }


  crearGatito(newAnimalito: IAnimalito):Observable<IAnimalito>{
    return this.http.post<IAnimalito>(`${environment.apiURL}/animalitos`,newAnimalito)
  }

}
