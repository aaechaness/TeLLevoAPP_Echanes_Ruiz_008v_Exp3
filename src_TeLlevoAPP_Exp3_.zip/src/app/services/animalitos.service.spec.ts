import { TestBed } from '@angular/core/testing';

import { AnimalitosService } from './animalitos.service';

describe('AnimalitosService', () => {
  let service: AnimalitosService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(AnimalitosService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
