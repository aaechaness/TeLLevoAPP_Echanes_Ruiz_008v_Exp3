import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { IAnimalito } from '../interfaces/ianimalito';
import { AnimalitosService } from '../services/animalitos.service';

@Component({
  selector: 'app-agregar-animalitos',
  templateUrl: './agregar-animalitos.page.html',
  styleUrls: ['./agregar-animalitos.page.scss'],
})
export class AgregarAnimalitosPage implements OnInit {

  newAnimalito: IAnimalito = {
    nombre: "", 
    tipoMascota: "",
    raza:""
  }

  constructor(private animalitoService: AnimalitosService, 
              private router: Router) { }

  ngOnInit() {
  }

  crearAnimalito(){
    this.animalitoService.crearGatito(this.newAnimalito).subscribe();
    this.router.navigateByUrl("/listar-animalitos");
  }

}
