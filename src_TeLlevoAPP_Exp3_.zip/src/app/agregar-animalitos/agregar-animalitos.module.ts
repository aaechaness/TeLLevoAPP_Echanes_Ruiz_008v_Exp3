import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { AgregarAnimalitosPageRoutingModule } from './agregar-animalitos-routing.module';

import { AgregarAnimalitosPage } from './agregar-animalitos.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    AgregarAnimalitosPageRoutingModule
  ],
  declarations: [AgregarAnimalitosPage]
})
export class AgregarAnimalitosPageModule {}
