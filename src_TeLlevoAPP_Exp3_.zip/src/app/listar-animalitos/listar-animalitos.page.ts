import { Component, OnInit } from '@angular/core';
import { InfiniteScrollCustomEvent, LoadingController } from '@ionic/angular';
import { AnimalitosService } from '../services/animalitos.service';

@Component({
  selector: 'app-listar-animalitos',
  templateUrl: './listar-animalitos.page.html',
  styleUrls: ['./listar-animalitos.page.scss'],
})
export class ListarAnimalitosPage implements OnInit {

  animalitos=[]
  constructor(private animalitosService: AnimalitosService, private loadCtrl: LoadingController) { }
 
  ngOnInit() {
    this.loadAnimalitos();
  }

  async loadAnimalitos(event?: InfiniteScrollCustomEvent){
    const loading = await this.loadCtrl.create({
      message : "Cargando..", 
      spinner: "bubbles"
    });
    await loading.present();

    this.animalitosService.listarAnimalitos().subscribe(
      (resp)=>{
        loading.dismiss();
        let listString = JSON.stringify(resp)     //debemos convertir a string el json que recibimos para el arreglo animalitos
        this.animalitos = JSON.parse(listString)
        event?.target.complete();
        console.log(this.animalitos);
      }, 
      (err) =>{
        console.log(err.message)
        loading.dismiss();
      }
    )
  }
}
