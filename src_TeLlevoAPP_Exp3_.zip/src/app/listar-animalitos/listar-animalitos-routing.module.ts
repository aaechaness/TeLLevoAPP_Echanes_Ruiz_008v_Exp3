import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { ListarAnimalitosPage } from './listar-animalitos.page';

const routes: Routes = [
  {
    path: '',
    component: ListarAnimalitosPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class ListarAnimalitosPageRoutingModule {}
