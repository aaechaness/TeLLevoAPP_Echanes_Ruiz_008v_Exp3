import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { ListarAnimalitosPageRoutingModule } from './listar-animalitos-routing.module';

import { ListarAnimalitosPage } from './listar-animalitos.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    ListarAnimalitosPageRoutingModule
  ],
  declarations: [ListarAnimalitosPage]
})
export class ListarAnimalitosPageModule {}
