export interface IAnimalitos {
    id: Number, 
    nombre: String, 
    tipoMascota: String,
    raza: String 
}
