export interface IAnimalito {
    nombre: String
    tipoMascota:String,
    raza:String
}
