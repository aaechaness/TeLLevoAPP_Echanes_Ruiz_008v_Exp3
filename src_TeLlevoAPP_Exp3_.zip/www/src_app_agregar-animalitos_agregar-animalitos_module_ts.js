"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_agregar-animalitos_agregar-animalitos_module_ts"],{

/***/ 4150:
/*!*************************************************************************!*\
  !*** ./src/app/agregar-animalitos/agregar-animalitos-routing.module.ts ***!
  \*************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AgregarAnimalitosPageRoutingModule": () => (/* binding */ AgregarAnimalitosPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 124);
/* harmony import */ var _agregar_animalitos_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./agregar-animalitos.page */ 3389);




const routes = [
    {
        path: '',
        component: _agregar_animalitos_page__WEBPACK_IMPORTED_MODULE_0__.AgregarAnimalitosPage
    }
];
let AgregarAnimalitosPageRoutingModule = class AgregarAnimalitosPageRoutingModule {
};
AgregarAnimalitosPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], AgregarAnimalitosPageRoutingModule);



/***/ }),

/***/ 2077:
/*!*****************************************************************!*\
  !*** ./src/app/agregar-animalitos/agregar-animalitos.module.ts ***!
  \*****************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AgregarAnimalitosPageModule": () => (/* binding */ AgregarAnimalitosPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 4666);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 2508);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var _agregar_animalitos_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./agregar-animalitos-routing.module */ 4150);
/* harmony import */ var _agregar_animalitos_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./agregar-animalitos.page */ 3389);







let AgregarAnimalitosPageModule = class AgregarAnimalitosPageModule {
};
AgregarAnimalitosPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _agregar_animalitos_routing_module__WEBPACK_IMPORTED_MODULE_0__.AgregarAnimalitosPageRoutingModule
        ],
        declarations: [_agregar_animalitos_page__WEBPACK_IMPORTED_MODULE_1__.AgregarAnimalitosPage]
    })
], AgregarAnimalitosPageModule);



/***/ }),

/***/ 3389:
/*!***************************************************************!*\
  !*** ./src/app/agregar-animalitos/agregar-animalitos.page.ts ***!
  \***************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AgregarAnimalitosPage": () => (/* binding */ AgregarAnimalitosPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _agregar_animalitos_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./agregar-animalitos.page.html?ngResource */ 6524);
/* harmony import */ var _agregar_animalitos_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./agregar-animalitos.page.scss?ngResource */ 6530);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 124);
/* harmony import */ var _services_animalitos_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../services/animalitos.service */ 7638);






let AgregarAnimalitosPage = class AgregarAnimalitosPage {
    constructor(animalitoService, router) {
        this.animalitoService = animalitoService;
        this.router = router;
        this.newAnimalito = {
            nombre: "",
            tipoMascota: "",
            raza: ""
        };
    }
    ngOnInit() {
    }
    crearAnimalito() {
        this.animalitoService.crearGatito(this.newAnimalito).subscribe();
        this.router.navigateByUrl("/listar-animalitos");
    }
};
AgregarAnimalitosPage.ctorParameters = () => [
    { type: _services_animalitos_service__WEBPACK_IMPORTED_MODULE_2__.AnimalitosService },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_3__.Router }
];
AgregarAnimalitosPage = (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_5__.Component)({
        selector: 'app-agregar-animalitos',
        template: _agregar_animalitos_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_agregar_animalitos_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], AgregarAnimalitosPage);



/***/ }),

/***/ 6530:
/*!****************************************************************************!*\
  !*** ./src/app/agregar-animalitos/agregar-animalitos.page.scss?ngResource ***!
  \****************************************************************************/
/***/ ((module) => {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJhZ3JlZ2FyLWFuaW1hbGl0b3MucGFnZS5zY3NzIn0= */";

/***/ }),

/***/ 6524:
/*!****************************************************************************!*\
  !*** ./src/app/agregar-animalitos/agregar-animalitos.page.html?ngResource ***!
  \****************************************************************************/
/***/ ((module) => {

module.exports = "<ion-header>\n  <ion-toolbar color=\"primary\">\n    <ion-title>Agregar</ion-title>\n    <ion-buttons slot=\"end\">\n      <ion-button [routerLink]=\"['/listar-animalitos']\">\n         Listar\n      </ion-button>\n    </ion-buttons>\n  </ion-toolbar>\n</ion-header>\n<ion-content>\n  <form>\n    <ion-item lines=\"full\">\n      <ion-label position=\"floating\">Nombre: </ion-label>\n      <ion-input type=\"text\" name=\"txtNombre\" [(ngModel)]=\"newAnimalito.nombre\" required></ion-input>\n    </ion-item>\n\n    <ion-item lines=\"full\">\n      <ion-label position=\"floating\">Tipo Mascota: </ion-label>\n      <ion-input type=\"text\" name=\"txtTipo\" [(ngModel)]=\"newAnimalito.tipoMascota\" required></ion-input>\n    </ion-item>\n\n    <ion-item lines=\"full\">\n      <ion-label position=\"floating\">Raza: </ion-label>\n      <ion-input type=\"text\" name=\"txtRaza\" [(ngModel)]=\"newAnimalito.raza\" required></ion-input>\n    </ion-item>\n\n    <ion-row>\n      <ion-col>\n        <ion-button (click)=\" crearAnimalito()\" expand=\"block\" fill=\"outline\" color=\"success\" shape=\"round\">\n          Agregar\n        </ion-button>\n      </ion-col>\n    </ion-row>\n  </form>\n</ion-content>\n";

/***/ })

}]);
//# sourceMappingURL=src_app_agregar-animalitos_agregar-animalitos_module_ts.js.map